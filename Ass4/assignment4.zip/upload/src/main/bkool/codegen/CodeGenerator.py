'''
 *   @author Nguyen Hua Phung
 *   @version 1.0
 *   23/10/2015
 *   This file provides a simple version of code generator
 *
'''
from Utils import *
from StaticCheck import *
from StaticError import *
from Emitter import Emitter
from Frame import Frame
from abc import ABC, abstractmethod
from functools import reduce

class MType(Type):
    
    def __init__(self,intype,outtype):
        #intype:list(Type)
        #outtype:Type
        self.partype = intype
        self.rettype = outtype

    def __str__(self):
        return "MType(["+",".join([str(x) for x in self.partype])+"],"+str(self.rettype)

    def accept(self, v, param):
        return None

class ArrayPointerType(Type):
    def __init__(self, ctype):
        #cname: String
        self.eleType = ctype

    def __str__(self):
        return "ArrayPointerType({0})".format(str(self.eleType))

    def accept(self, v, param):
        return None


        
class MethodEnv():
    def __init__(self, emit, classname, parentname, declist):
        #emit:Emitter
        #classname:String
        #parentname:String
        #declist:list(Decl)
        self.emit = emit
        self.classname = classname
        self.parentname = parentname
        self.declist = declist

class StmtEnv():
    def __init__(self, frame, sym, methodenv):
        #frame: Frame
        #sym: List[Symbol]

        self.frame = frame
        self.sym = sym
        self.method = methodenv

class ExprEnv():
    def __init__(self, isLeft, isFirst, stmt):
        #stmt: StmtEnv
        #isLeft: Boolean
        #isFirst: Boolean
        self.stmt = stmt
        self.isLeft = isLeft
        self.isFirst = isFirst

class Val(ABC):
    pass

class Index(Val):
    def __init__(self, value):
        #value: Int

        self.value = value

class CName(Val):
    def __init__(self, value):
        #value: String

        self.value = value

class Member:
    def __init__(self,name,skind,mtype,value = None):
        #name:String
        #skind:SIKind
        #kind:Kind
        #mtype:Type
        #value:Expr
        self.name = name
        self.skind = skind
        self.mtype = mtype
        self.value = value
class ClassData:
    def __init__(self,cname,pname,mem):
        #cname:String -- class name
        #pname:String -- parent name
        #mem:list(Member)
        self.cname = cname
        self.pname = pname
        self.mem = mem

class GlobalEnvironment(BaseVisitor):
    def __init__(self,env):
        #env:list(ClassData)
        self.env = env

    def visitProgram(self,ast:Program,o):
        return list(reduce(lambda x,y: self.visit(y,x),ast.decl,self.env))
    
    def visitClassDecl(self,ast:ClassDecl,o):
        return [ClassData(ast.classname.name,
                        ast.parentname.name if ast.parentname else "",
                        list(reduce(lambda x,y: self.visit(y,x),ast.memlist,[])))] + o
      
    def visitAttributeDecl(self,ast,o):
        name,mtype,e = self.visit(ast.decl,o)
        return [Member(ast.kind,name,mtype,e)] + o

    def visitVarDecl(self,ast,o):
        return ast.variable.name,ast.varType,None

    def visitConstDecl(self,ast,o):
        return ast.constant.name,ast.constType,ast.value

    def visitMethodDecl(self,ast:MethodDecl,o):
        return [Member(ast.name.name,
                        ast.sikind,
                        MType([x.varType for x in ast.param],ast.returnType))] + o
    

    
class CodeGenerator(Utils):
    def __init__(self):
        self.libName = "io"

    def init(self):
        mem = [Member("readInt",Static(),MType(list(),IntType()),None),
                Member("writeInt",Static(),MType([IntType()],VoidType()),None),
                Member("writeIntLn",Static(),MType([IntType()],VoidType()),None)]
        return [ClassData("io","",mem)]

    def gen(self, ast, dir_):
        #ast: AST
        #dir_: String

        gl = self.init()
        ge = GlobalEnvironment(gl)
        glenv = ge.visit(ast,None)
        gc = CodeGenVisitor(ast, glenv, dir_)
        gc.visit(ast, None)


class CodeGenVisitor(BaseVisitor, Utils):
    def __init__(self, astTree, env, dir_):
        #astTree: AST
        #env: List[ClassData]
        #dir_: File

        self.astTree = astTree
        self.env = env
        self.path = dir_
        

    def visitProgram(self, ast, c):
        #ast: Program
        #c: Any
        for x in ast.decl:
            self.visit(x,c)
        return c

    def visitClassDecl(self, ast, c):
        #ast:ClassDecl
        #c:Any
        emit = Emitter(self.path + "/" + ast.classname.name + ".j")
        parentname = ast.parentname.name if ast.parentname else "java.lang.Object"
        emit.printout(emit.emitPROLOG(ast.classname.name, parentname))
        e = MethodEnv(emit, ast.classname.name,parentname,[])
        list(map(lambda x: self.visit(x, e),ast.memlist))
        # generate default constructor
        self.genMETHOD(MethodDecl(Instance(),Id("<init>"), list(), None, Block(list(), list())), 
            e, 
            Frame("<init>", VoidType()))
        emit.emitEPILOG()
        return c

    def genMETHOD(self, consdecl, o, frame):
        #consdecl: MethodDecl
        #o: MethodEnv
        #frame: Frame

        isInit = consdecl.returnType is None
        isMain = consdecl.name.name == "main" and len(consdecl.param) == 0 and type(consdecl.returnType) is VoidType
        returnType = VoidType() if isInit else consdecl.returnType
        methodName = "<init>" if isInit else consdecl.name.name
        intype = [ArrayPointerType(StringType())] if isMain else list()
        mtype = MType(intype, returnType)
        emit = o.emit
        emit.printout(emit.emitMETHOD(methodName, mtype,type(consdecl.sikind) is Static, frame))

        frame.enterScope(True)
        
        # Generate code for parameter declarations
        if (type(consdecl.sikind) is Instance):
            emit.printout(emit.emitVAR(frame.getNewIndex(),"this",ClassType(Id(o.classname)),frame.getStartLabel(),frame.getEndLabel(),frame))
        elif isMain:
            emit.printout(emit.emitVAR(frame.getNewIndex(), "args", ArrayPointerType(StringType()), frame.getStartLabel(), frame.getEndLabel(), frame))
        #TODO generate code for parameter
        #TODO generate code for local declarations
        body = consdecl.body
        emit.printout(emit.emitLABEL(frame.getStartLabel(), frame))

        # Generate code for statements
        if isInit:
            emit.printout(emit.emitREADVAR("this", ClassType(Id(o.classname)), 0, frame))
            emit.printout(emit.emitINVOKESPECIAL(frame))
        list(map(lambda x: self.visit(x, StmtEnv(frame, [], o)), body.stmt))

        emit.printout(emit.emitLABEL(frame.getEndLabel(), frame))
        if type(returnType) is VoidType:
            emit.printout(emit.emitRETURN(VoidType(), frame))
        emit.printout(emit.emitENDMETHOD(frame))
        frame.exitScope();

    def visitMethodDecl(self, ast, o):
        #ast: MethodDecl
        #o: MethodEnv
        frame = Frame(ast.name, ast.returnType)
        self.genMETHOD(ast, o, frame)
        return o

    def visitCallStmt(self, ast, o):
        #ast: CallStmt
        #o: StmtEnv
        emit = o.method.emit
        frame = o.frame

        cname,ctype = self.visit(ast.obj, ExprEnv(False,True,o))
        symclass = self.lookup(ctype.classname.name,self.env,lambda x:x.cname)
        methodsym = self.lookup(ast.method.name,symclass.mem,lambda x:x.name)
        mtype = methodsym.mtype

        in_ = ("", list())
        for x in ast.param:
            str1, typ1 = self.visit(x, ExprEnv(False, True,o))
            in_ = (in_[0] + str1, in_[1].append(typ1))
        emit.printout(in_[0])
        emit.printout(emit.emitINVOKESTATIC(cname + "/" + ast.method.name, mtype, frame))

    def visitId(self,ast,o):
        #ast:Id
        #o:ExprEnv
        sym = self.lookup(ast.name,self.env,lambda x: x.cname)
        if sym:
            return (sym.cname,ClassType(Id(sym.cname)))
        else:
            raise Undeclared(Identifier(),ast.name)

    def visitIntLiteral(self, ast, o):
        #ast: IntLiteral
        #o: ExprEnv
        emit = o.stmt.method.emit
        frame = o.stmt.frame
        return emit.emitPUSHICONST(ast.value, frame), IntType()

    
