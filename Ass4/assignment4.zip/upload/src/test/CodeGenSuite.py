import unittest
from TestUtils import TestCodeGen
from AST import *


class CheckCodeGenSuite(unittest.TestCase):
    def test_int_ast(self):
        input = Program([ClassDecl(Id("a"),[
    		MethodDecl(Static(),Id("main"),[],VoidType(),Block([],[
    			CallStmt(Id("io"),Id("writeInt"),[IntLiteral(5)])]))])])
        expect = "5"
        self.assertTrue(TestCodeGen.test(input,expect,501))
