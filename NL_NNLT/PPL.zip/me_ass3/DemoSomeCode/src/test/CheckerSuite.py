import unittest
from TestUtils import TestChecker
from AST import *

class CheckerSuite(unittest.TestCase):


    def test_0(self):
        """Simple program: int main() {} """
        input = """var x:integer;"""
        expect = "No entry point"
        self.assertTrue(TestChecker.test(input,expect,400))
    def test_1(self):
        """Simple program: int main() {} """
        input = """
            var x,t:integer;
            procedure main(x,y:integer);
            var a:real;
            begin

            end
            var x:real;"""
        expect = "Redeclared Variable: x"
        self.assertTrue(TestChecker.test(input,expect,401))
    def test_2(self):
        """Simple program: int main() {} """
        input = """
            var x,t:integer;         
            procedure main(x,y:integer);
            var a:real;
            begin
            end

            procedure main(x,y:integer);
            var a:real;
            begin

            end
            var x:real;"""
        expect = "Redeclared Procedure: main"
        self.assertTrue(TestChecker.test(input,expect,402))
    def test_3(self):
        """Simple program: int main() {} """
        input = """var x:integer;
        var r:integer;
        var x:integer;"""
        expect = "Redeclared Variable: x"
        self.assertTrue(TestChecker.test(input,expect,403))
    def test_4(self):
        """Simple program: int main() {} """
        input = """var x:integer;
        var r:integer;
        procedure main();
        var a:real;
        begin

        end
        var r:real;
        """
        expect = "Redeclared Variable: r"
        self.assertTrue(TestChecker.test(input,expect,404))
    def test_5(self):
        """Simple program: int main() {} """
        input = """
        var x:integer;
        var r:integer;
        procedure main();
        var x:integer;
        begin

        end
        var x:integer;
        """
        expect = "Redeclared Variable: x"
        self.assertTrue(TestChecker.test(input,expect,405))
    def test_6(self):
        """Simple program: int main() {} """
        input = """
        var x:integer;
        var r:integer;
        function foo1(x,y:integer):integer;
            var x:real;y:integer;
            begin

            end
        procedure main();
            begin

            end"""
        expect = "Redeclared Variable: x"
        self.assertTrue(TestChecker.test(input,expect,406))
    def test_7(self):
        """Simple program: int main() {} """
        input = """
        var x:integer;
        var r:integer;
        function foo1(x,y:integer):integer;
            var x:real;y:integer;
            begin
            end
        """
        expect = "No entry point"
        self.assertTrue(TestChecker.test(input,expect,407))
    def test_8(self):
        """Simple program: int main() {} """
        input = """
            var x,t:integer;         
            function foo1(x,y:integer):integer;
            var a:real;
            begin
            end

            procedure foo1(x,y:integer);
            var a:real;
            begin

            end"""
        expect = "Redeclared Procedure: foo1"
        #expect = "Redeclared Function: foo1"
        self.assertTrue(TestChecker.test(input,expect,408))
    def test_9(self):
        input = """
            var x,t:integer;         
            procedure main(x,y:integer);
            var a:real;
            begin
                foo1();
            end
            """
        expect = "No entry point"
        self.assertTrue(TestChecker.test(input,expect,409))
    def test_10(self):
        input = """
            var x,t:integer;         
            function main(x,y:integer):integer;
            var a:real;
            begin
                foo1();
            end
            """
        expect = "No entry point"
        self.assertTrue(TestChecker.test(input,expect,410))


    def test_11(self):
        input = """
            var x,t:integer;         
            procedure main(x,y:integer);
            var a:real;
            begin
                //foo1();
                return 1;
            end
            """
        expect = "No entry point"
        self.assertTrue(TestChecker.test(input,expect,411))

    def test_12(self):
        input = """
            var x,t:integer; 
            procedure foo1(x,y:integer);
            var a:real;
            begin
                
            end        
            procedure main();
            var a:real;
            begin
                foo:=a;
                return;
            end
            """
        expect = "Undeclared Identifier: foo"
        self.assertTrue(TestChecker.test(input,expect,412))
    def test_13(self):
        input = """
            var x,t:integer; 
            procedure foo1(x,y:integer);
            var a:real;
            begin
                
            end        
            procedure main();
            var a:real;
            begin
                foo1(x,y,a);
                return;
            end
            """
        expect = "Undeclared Identifier: y"
        self.assertTrue(TestChecker.test(input,expect,413))
    def test_14(self):
        input = """
            var x,t:integer; 
            procedure foo1(x,y:integer);
            var a:real;
            begin
                
            end        
            procedure main();
            var a:real;
            begin
                foo1(x,y);
                return;
            end
            """
        expect = "Undeclared Identifier: y"
        self.assertTrue(TestChecker.test(input,expect,414))
    def test_15(self):
        input = """
            var x,t:integer; 
            procedure foo1(x,y:integer);
            var a:real;
            begin
                
            end        
            procedure main();
            var a:real;
            begin
                foo1(x,y);
                return;
            end
            """
        expect = "Undeclared Identifier: y"
        self.assertTrue(TestChecker.test(input,expect,415))
    def test_16(self):
        input = """
            var x,t:integer; 
            procedure foo1(x,y:integer);
            var a:real;
            begin
                
            end        
            procedure main();
            var a:integer;
            begin
                a:=10.5;
                return;
            end
            """
        expect = "Type Mismatch In Statement: AssignStmt(Id(a),FloatLiteral(10.5))"
        self.assertTrue(TestChecker.test(input,expect,416))

    def test_17(self):
        input = """
            var x,t:integer; 
            procedure foo1(x,y:integer);
            var a:real;
            begin
                
            end        
            procedure main();
            var a:integer;
                c:real;
            begin
                a:=c:=10.5;
                return;
            end
            """
        expect = "Type Mismatch In Statement: AssignStmt(Id(a),Id(c))"
        self.assertTrue(TestChecker.test(input,expect,417))

    def test_18(self):
        input = """
            var x,t:integer; 
            function foo100(x,y:integer):array[1 .. 10] of integer;
            var a:array[1 .. 4] of integer;
                b:array[1 .. 5] of real;
                c:array[1 .. 10] of real;
            begin
                return c;
            end        
            procedure main();
            var a:integer;
                c:real;
            begin
            end
            """
        expect = "Type Mismatch In Statement: Return(Some(Id(c)))"
        self.assertTrue(TestChecker.test(input,expect,418))
    def test_19(self):
        input = """
            var x,t:integer; 
            function foo100(x,y:integer):array[1 .. 10] of integer;
            var a:array[1 .. 4] of integer;
                b:array[1 .. 5] of real;
                c:array[1 .. 10] of integer;
            begin
                return a;
            end        
            procedure main();
            var a:integer;
                c:real;
            begin
            end
            """
        expect = "Type Mismatch In Statement: Return(Some(Id(a)))"
        self.assertTrue(TestChecker.test(input,expect,419))
    def test_20(self):
        input = """
            var x,t:integer; 
            procedure foo100(x:array[1 .. 2]of integer;y:integer);
            var a:array[1 .. 4] of integer;
                b:array[1 .. 5] of real;
                c:array[1 .. 10] of integer;
            begin

            end        
            procedure main();
            var a:integer;
                c:real;
                d:array[1 .. 10] of integer;
                e:array[1 .. 10] of integer;
            begin
                foo100(e,a);
            end
            """
        expect = "Type Mismatch In Expression: CallStmt(Id(foo100),[Id(e),Id(a)])"
        self.assertTrue(TestChecker.test(input,expect,420))

    def test_21(self):
        input = """
            var x,t:integer; 
            function foo100(x:array[1 .. 2]of integer;y:integer):array[1 .. 5]of integer;
            var a:array[1 .. 4] of integer;
                b:array[1 .. 5] of integer;
                c:array[1 .. 10] of integer;
            begin
                return b;
            end        
            procedure main();
            var a:integer;
                c:real;
                d:array[1 .. 2] of integer;
                e:array[1 .. 2] of integer;
            begin
                d:=foo100(e,a);
            end
            """
        expect = "Type Mismatch In Statement: "+str(Assign(Id('d'),CallExpr(Id('foo100'),[Id('e'),Id('a')])))
        self.assertTrue(TestChecker.test(input,expect,421))
    def test_22(self):
        input = """
            var x,t:integer; 
            function foo100(x:array[1 .. 2]of integer;y:integer):array[1 .. 5]of integer;
            var a:array[1 .. 4] of integer;
                b:array[1 .. 5] of integer;
                c:array[1 .. 10] of integer;
            begin
                return b;
            end        
            procedure main();
            var a:integer;
                c:real;
                d:array[1 .. 2] of integer;
                e:array[1 .. 2] of integer;
            begin
                d:=foo100(e,a);// mac du day co loi
            end
            """
        expect = "Type Mismatch In Statement: AssignStmt(Id(d),CallExpr(Id(foo100),[Id(e),Id(a)]))"
        self.assertTrue(TestChecker.test(input,expect,422))
    def test_23(self):
        input = """
            var x,t:integer; 
            function foo100(x:array[1 .. 2]of integer;y:integer):array[1 .. 5]of integer;
            var a:array[1 .. 4] of integer;
                b:array[1 .. 5] of integer;
                c:array[1 .. 10] of integer;
            begin
                return b;
            end        
            procedure main();
            var a:integer;
                c:real;
                d:array[1 .. 2] of integer;
                e:array[1 .. 2] of integer;
            begin
                d:=foo100(e,a,c);// mac du day co loi
            end
            """
        expect = "Type Mismatch In Expression: CallExpr(Id(foo100),[Id(e),Id(a),Id(c)])"
        self.assertTrue(TestChecker.test(input,expect,423))
    
    ################################### chu y test này
    def test_24(self):
        input = """
            var x,t:integer; 
            function foo100(x:array[1 .. 2]of integer;y:integer):integer;
            var a:array[1 .. 4] of integer;
                c:integer;
            begin
                return c;
            end        
            procedure main();
            var a,d:integer;
                c:real;
                e:array[1 .. 2] of integer;
            begin
                d:=foo100(e,a,f);// mac du day co loi
            end
            """
        expect = "Undeclared Identifier: f"
        expect2 = "Type Mismatch In Statement: CallExpr(Id(foo100),[Id(e),Id(a),Id(f)])"
        self.assertTrue(TestChecker.test(input,expect,424))

    def test_25(self):
        input = """
            var x,t:integer; 
            function foo100(x:array[1 .. 2]of integer;y:integer):integer;
            var a:array[1 .. 4] of integer;
                c:integer;
            begin
                return c;
            end        
            procedure main();
            var a,d:integer;
                c:real;
                e:array[1 .. 2] of integer;
            begin
                d:=foo100(e,c);// mac du day co loi
            end
            """
        expect = "Type Mismatch In Expression: CallExpr(Id(foo100),[Id(e),Id(c)])"
        self.assertTrue(TestChecker.test(input,expect,425))
    def test_26(self):
        input = """
            var x,t:integer; 
            function foo100(x:integer):integer;
            begin
                return x;
            end        
            procedure main();
            var a,d:integer;
                c:real;
                f:boolean;
            begin
                f:=t:=d:=foo100(a);// mac du day co loi
            end
            """
        expect = "Type Mismatch In Statement: AssignStmt(Id(f),Id(t))"
        self.assertTrue(TestChecker.test(input,expect,426))
    def test_27(self):
        input = """
            var t:array[1 .. 2] of integer; 
            function foo100(x:integer):integer;
            begin
                return x;
            end        
            procedure main();
            var a,d:integer;
                c:real;
                f:boolean;
            begin
                a:=t[1.5];
            end
            """
        expect = "Type Mismatch In Expression: ArrayCell(Id(t),FloatLiteral(1.5))"
        self.assertTrue(TestChecker.test(input,expect,427))
    def test_28(self):
        input = """
            var t:array[1 .. 2] of integer; 
            function foo100(x:integer):integer;
            begin
                return x;
            end        
            procedure main();
            var a,d:integer;
                c:real;
                f:boolean;
            begin
                a:=t[foo100(d)*1.5];
            end
            """
        expect = "Type Mismatch In Expression: ArrayCell(Id(t),BinaryOp(*,CallExpr(Id(foo100),[Id(d)]),FloatLiteral(1.5)))"
        self.assertTrue(TestChecker.test(input,expect,428))
    def test_29(self):
        input = """
            var t:array[1 .. 2] of integer; 
            function foo100(x:integer):integer;
            begin
                return x;
            end        
            procedure main();
            var a,d:integer;
                c:real;
                f:boolean;
            begin
                a:=t[foo100(d)/15];
            end
            """
        expect = "Type Mismatch In Expression: ArrayCell(Id(t),BinaryOp(/,CallExpr(Id(foo100),[Id(d)]),IntLiteral(15)))"
        self.assertTrue(TestChecker.test(input,expect,429))
    def test_30(self):
        input = """
            var t:array[1 .. 2] of integer; 
            procedure foo2();
            var n:real;
                i:integer;
            begin
                for i:=1 to n do
                begin
                    putInt(5);
                    putInt(10);
                end
            end        
            procedure main();
            begin
                foo2();
            end
            """
        expect = "Type Mismatch In Statement: For(Id(i)IntLiteral(1),Id(n),True,[CallStmt(Id(putInt),[IntLiteral(5)]),CallStmt(Id(putInt),[IntLiteral(10)])])"
        self.assertTrue(TestChecker.test(input,expect,430))
    def test_31(self):
        input = """
            var t:array[1 .. 2] of integer; 
            procedure foo2();
            var n:integer;
                i:integer;
            begin
                for i:=1 to n do
                begin
                    putInt(a5);
                    putInt(10);
                end
            end        
            procedure main();
            begin
                foo2();
            end
            """
        expect = "Undeclared Identifier: a5"
        self.assertTrue(TestChecker.test(input,expect,431))
    def test_31(self):
        input = """
            var t:array[1 .. 2] of integer; 
            procedure foo2();
            var n:integer;
                i:integer;
            begin
                for i:=2*20 to n do
                begin
                    putInt(a5);
                    putInt(10);
                end
            end        
            procedure main();
            begin
                foo2();
            end
            """
        expect = "Undeclared Identifier: a5"
        self.assertTrue(TestChecker.test(input,expect,431))
    def test_32(self):
        input = """
            var t:array[1 .. 2] of integer; 
            procedure foo2();
            var n:integer;
                i:integer;
            begin
                for i:=(20 mod 2) to n do
                begin
                    putInt(a5);
                    putInt(10);
                end
            end        
            procedure main();
            begin
                foo2();
            end
            """
        expect = "Undeclared Identifier: a5"
        self.assertTrue(TestChecker.test(input,expect,432))
    def test_33(self):
        input = """
            var t:array[1 .. 2] of integer; 
            procedure foo2();
            var n:integer;
                i:integer;
            begin
                for i:=(20 mod 2) to n*3 do
                begin
                    putInt(a5);
                    putInt(10);
                end
            end        
            procedure main();
            begin
                foo2();
            end
            """
        expect = "Undeclared Identifier: a5"
        self.assertTrue(TestChecker.test(input,expect,433))
    def test_34(self):
        input = """
            var t:array[1 .. 2] of integer;        
            procedure main();
            var a,b:integer;
            begin
                if(a+b) then
                    a:=b;
                else b:=a; 
            end
            """
        expect = "Type Mismatch In Statement: If(BinaryOp(+,Id(a),Id(b)),[AssignStmt(Id(a),Id(b))],[AssignStmt(Id(b),Id(a))])"
        self.assertTrue(TestChecker.test(input,expect,434))
    def test_35(self):
        input = """
            var t:array[1 .. 2] of integer;        
            procedure main();
            var a,b:integer;
                c:boolean;
            begin
                if(not c) then
                    a:=b1;
            end
            """
        expect = "Undeclared Identifier: b1"
        self.assertTrue(TestChecker.test(input,expect,435))
    def test_36(self):
        input = """
            var t:array[1 .. 2] of integer;        
            procedure main();
            var a,b:integer;
                c:boolean;
            begin
                if(not c) then
                    if (a>b) then
                        a:=b;
                    else b:=a;
                else c:=a;
            end
            """
        expect = "Type Mismatch In Statement: AssignStmt(Id(c),Id(a))"
        self.assertTrue(TestChecker.test(input,expect,436))
    def test_37(self):
        input = """
            var t:array[1 .. 2] of integer;        
            procedure main();
            var n,S:integer;
                c:boolean;
            begin
                n:=1;
                S:=0;
                while (n<10) and (s<20) do
                    n:=nk+1;
            end
            """
        expect = "Undeclared Identifier: nk"
        self.assertTrue(TestChecker.test(input,expect,437))
    def test_38(self):
        input = """
            var t:array[1 .. 2] of integer;        
            procedure main();
            var n,S:integer;
                c:boolean;
            begin
                n:=1;
                S:=0;
                while (n+S) do
                    n:=n+1;
            end
            """
        expect = "Type Mismatch In Statement: While(BinaryOp(+,Id(n),Id(S)),[AssignStmt(Id(n),BinaryOp(+,Id(n),IntLiteral(1)))])"
        self.assertTrue(TestChecker.test(input,expect,438))

    def test_39(self):
        input = """
            var t:array[1 .. 2] of integer;        
            procedure main();
            var n,S:integer;
                c:boolean;
            begin
                break;
            end
            """
        expect = "Break Not In Loop"
        self.assertTrue(TestChecker.test(input,expect,439))
    def test_40(self):
        input = """
            var t:array[1 .. 2] of integer;        
            procedure main();
            var n,S:integer;
                c:boolean;
            begin
                continue;
            end
            """
        expect = "Continue Not In Loop"
        self.assertTrue(TestChecker.test(input,expect,440))
    def test_41(self):
        input = """
            var t:array[1 .. 2] of integer;        
            procedure main();
            var n,S:integer;
                c:boolean;
            begin
                continue;
                return;
            end
            """
        expect = "Continue Not In Loop"
        self.assertTrue(TestChecker.test(input,expect,441))
    def test_42(self):
        input = """
            var t:array[1 .. 2] of integer;        
            procedure main();
            var n,S:integer;
                c:boolean;
            begin
                break;
            end
            """
        expect = "Break Not In Loop"
        self.assertTrue(TestChecker.test(input,expect,442))
    def test_43(self):
        input = """
            var t:array[1 .. 2] of integer;
            procedure foo1();
            begin
            end        
            procedure main();
            var n,S:integer;
                c:boolean;
            begin
                for n:=1 downto S do
                    if(S=5)then break;
                    break;
                break;
            end
            """
        expect = "Break Not In Loop"
        self.assertTrue(TestChecker.test(input,expect,443))
    def test_44(self):
        input = """
            var t:array[1 .. 2] of integer;
            function foo1():integer;
            begin
                return 1;
            end        
            procedure main();
            var n,S:integer;
                c:boolean;
            begin
                foo2(b);
                for n:=1 downto S do
                    if(S=5)then break;
            end
            """
        expect = "Undeclared Identifier: b"
        self.assertTrue(TestChecker.test(input,expect,444))
    def test_45(self):
        input = """
            var t:array[1 .. 2] of integer;
            function foo1():integer;
            begin
                return 1;
            end        
            procedure main();
            var n,S:integer;
                c:boolean;
            begin
                break;
                for n:=1 downto S do
                    if(S=5)then break;
            end
            """
        expect = "Break Not In Loop"
        self.assertTrue(TestChecker.test(input,expect,445))
    def test_46(self):
        input = """
            var t:array[1 .. 2] of integer;
            function foo1():integer;
            begin
                return 1;
            end        
            procedure main();
            var n,S:integer;
                c:boolean;
            begin
                break;
                for n:=1 downto S do
                    if(S=5)then break;
            end
            """
        expect = "Break Not In Loop"
        self.assertTrue(TestChecker.test(input,expect,446))
    def test_47(self):
        input = """
            var t:array[1 .. 2] of integer;
            function foo1():integer;
            begin
                return 1;
            end        
            procedure main();
            var n,S:integer;
                c:boolean;
            begin
                n:=foo1()+0.5;
                for n:=1 downto S do
                begin
                    if(S=5)then break;
                    break;
                end
                    
            end
            """
        expect = "Type Mismatch In Statement: AssignStmt(Id(n),BinaryOp(+,CallExpr(Id(foo1),[]),FloatLiteral(0.5)))"
        self.assertTrue(TestChecker.test(input,expect,447))
    def test_48(self):
        input = """
            var t:array[1 .. 2] of integer;
            function foo1():integer;
            begin
                return 1;
            end        
            procedure main();
            var n,S:integer;
                c:boolean;
            begin
                n:=foo1();
                for n:=1 downto S do
                begin
                end
                continue;
                break;
                a:=b;
                    
            end
            """
        expect = "Continue Not In Loop"
        self.assertTrue(TestChecker.test(input,expect,448))
    def test_49(self):
        input = """
            var t:array[1 .. 2] of integer;
            function foo1():integer;
            begin
                return 1;
            end        
            procedure main1();
            var n,S:integer;
                c:boolean;
            begin
                n:=foo1();                    
            end
            """
        expect = "No entry point"
        self.assertTrue(TestChecker.test(input,expect,449))
    def test_50(self):
        input = """
            var t:array[1 .. 2] of integer;
            function foo1():integer;
            begin
                return 1.5;
            end
            procedure main();
            begin end        
            """
        expect = "Type Mismatch In Statement: Return(Some(FloatLiteral(1.5)))"
        self.assertTrue(TestChecker.test(input,expect,450))

    def test_51(self):
        input = """
            var t:array[1 .. 2] of integer;

            function foo1():integer;
            begin
                return 1;
            end 
            function foo2():integer;
            begin
                return foo3();
            end
            function foo3():integer;
            begin
                return 1;
            end        
            procedure main();
            var n,S:integer;
                c:boolean;
            begin
                q:=foo1();
            end
            """
        expect = "Undeclared Identifier: q"
        self.assertTrue(TestChecker.test(input,expect,451))
    def test_52(self):
        input = """
            var t:array[1 .. 2] of integer;

            function foo1(x:integer):integer;
            begin
                return 1;
            end        
            procedure main();
            var n,S:integer;
                c:boolean;
            begin
                foo1(1.5*5);
            end
            """
        expect = "Undeclared Procedure: foo1"
        self.assertTrue(TestChecker.test(input,expect,452))
    def test_53(self):
        input = """
            var t:array[1 .. 2] of integer;

            procedure foo1(x:integer);
            begin
                return;
            end        
            procedure main();
            var n,S:integer;
                c:boolean;
            begin
                foo1(1.5*5);
            end
            """
        expect = "Type Mismatch In Expression: CallStmt(Id(foo1),[BinaryOp(*,FloatLiteral(1.5),IntLiteral(5))])"
        self.assertTrue(TestChecker.test(input,expect,453))
    def test_54(self):
        """More complex program"""
        input = """
        function f(i:integer;j:real):real;
        var a: real;
            b: integer;
            c: string;
        begin
            if a > 0 then begin
                if b<0.5 then 
                begin
                    a:=8;
                    return 1;
                end
            end
        end
        procedure main ();
        begin
        end
        """   
        expect = "Function f Not Return "
        self.assertTrue(TestChecker.test(input,expect,454))
    def test_55(self):
        """More complex program"""
        input = """
        function f(i:integer;j:real):real;
        var a: real;
            b: integer;
            c: string;
        begin
            if a > 0 then begin
                if b<0.5 then 
                begin
                    a:=8;
                    return;
                end
            end
        end
        procedure main ();
        begin
        end
        """  
        expect = "Type Mismatch In Statement: Return(None)"
        self.assertTrue(TestChecker.test(input,expect,455))
    def test_56(self):
        """More complex program"""
        input = """
        function f(i:integer;j:real):real;
        var a: real;
            b: integer;
            c: string;
        begin
            if a > 0 then begin
                if b<0.5 then 
                begin
                    i := f;
                    return 1;
                end
            end
        end
        procedure main();
        begin end
        """ 
        expect = "Undeclared Identifier: f"
        self.assertTrue(TestChecker.test(input,expect,456))
    def test_57(self):
        """More complex program"""
        input = """
        function f(i:integer;j:real):real;
        var a: real;
            b: integer;
            c: string;
        begin
            if a > 0 then begin
                if b<0.5 then 
                begin
                    for b:=1 to 5 do
                    begin
                        b:=b+1;
                        return b;
                    end
                end
            end
        end
        procedure main ();
        begin
        end
        """ 
        expect = "Function f Not Return "
        self.assertTrue(TestChecker.test(input,expect,457))
    def test_58(self):
        input = """
        function f(i:integer;j:real):real;
        var a: real;
            b: integer;
            c: string;
        begin
            if a > 0 then begin
                if b<0.5 then 
                begin
                    for b:=1 to 5 do
                    begin
                        b:=b+1;
                    end
                end
                break;
            end
            return b;
        end
        procedure main ();
        begin
        end
        """ 
        expect = "Break Not In Loop"
        self.assertTrue(TestChecker.test(input,expect,458))
    def test_59(self):
        """More complex program"""
        input = """
        function f(i:integer;j:real):real;
        var a: real;
            b: integer;
            c: string;
        begin
            if a > 0 then begin
                if b<0.5 then 
                begin
                    while b>10 do
                    begin
                    end
                    return 1;
                end
            end
        end
        procedure main ();
        var x:real;
        begin
            x:=f(1,1);
        end
        """ 
        expect = "Function f Not Return "
        self.assertTrue(TestChecker.test(input,expect,459))
    def test_60(self):
        """More complex program"""
        input = """
        procedure main ();
        var x:real;
        begin
            with a,b:integer;c:real; do
            begin
                a:=c;
            end
        end
        """ 
        expect = "Type Mismatch In Statement: AssignStmt(Id(a),Id(c))"
        self.assertTrue(TestChecker.test(input,expect,460))
    def test_61(self):
        """More complex program"""
        input = """
        procedure main ();
        var x:real;
        begin
            with a,b:integer;b:real; do
            begin
                a:=c;
            end
        end
        """ 
        expect = "Redeclared Variable: b"
        self.assertTrue(TestChecker.test(input,expect,461))
    def test_62(self):
        """More complex program"""
        input = """
        function f(i:integer):real;
        var f:integer;
        begin
            return f(5);
        end
        procedure main ();
        var x:real;
        begin
            with a,b:integer;b:real; do
            begin
                a:=c;
            end
        end
        """ 
        expect = "Undeclared Function: f"
        self.assertTrue(TestChecker.test(input,expect,462))
    def test_63(self):
        """More complex program"""
        input = """
        function f():integer;
        var f:integer;
        begin
            return 200;
        end
        procedure main ();
        var main:integer;
        begin
            main:=f();
            putIntLn(main);
            with
                i:integer;
                main:integer;
                f:integer;
            do begin
                main:=i:=f:=10; 
                break;
            end

        end
        """ 
        expect = "Break Not In Loop"
        self.assertTrue(TestChecker.test(input,expect,463))
    def test_64(self):
        """More complex program"""
        input = """
        procedure main ();
        var a,b,c:boolean;
            d,e:integer;
        begin
            with
                d: boolean;
            do begin
                d:=d+1;
            end
        end
        """ 
        expect = "Type Mismatch In Expression: BinaryOp(+,Id(d),IntLiteral(1))"
        self.assertTrue(TestChecker.test(input,expect,464))
    def test_65(self):
        """More complex program"""
        input = """
        function f1():integer;
        begin
            return f2();
        end
        function f2():integer;
        begin
            return 500;
        end
        function f3():integer;
        begin
            return f1()+f2()*f1();
        end

        procedure main ();
        var a:array[1 .. 5] of integer;
            d,e:integer;
        begin
            g:=d*e;
            a[1] := f3();
            e:= a[a[f3()]];
            e:= a[a[f3()/f2()]];
        end
        var g:real;
        """ 
        expect = "Type Mismatch In Expression: ArrayCell(Id(a),BinaryOp(/,CallExpr(Id(f3),[]),CallExpr(Id(f2),[])))"
        self.assertTrue(TestChecker.test(input,expect,465))

    def test_66(self):
        """More complex program"""
        input = """
        function f1():array[1 .. 3]of integer;
        var x :array[1 .. 3] of integer;
        begin
            return x;
        end
        procedure main ();
        var a:array[1 .. 5] of integer;
            d:integer;
            e:real;
        begin
            f1()[2]:=d;
            f1()[2]:=g;
        end
        var g:real;
        """ 
        expect = "Type Mismatch In Statement: AssignStmt(ArrayCell(CallExpr(Id(f1),[]),IntLiteral(2)),Id(g))"
        self.assertTrue(TestChecker.test(input,expect,466))
    def test_67(self):
        """More complex program"""
        input = """
        function f1():array[1 .. 3]of integer;
        var x :array[1 .. 3] of integer;
        begin
            return x;
        end
        procedure main ();
        var a:array[1 .. 5] of integer;
            d:integer;
            e:real;
        begin
            d[2]:= e;
        end
        var g:real;
        """ 
        expect = "Type Mismatch In Expression: ArrayCell(Id(d),IntLiteral(2))"
        self.assertTrue(TestChecker.test(input,expect,467))
    def test_68(self):
        """More complex program"""
        input = """
        function f1():array[1 .. 3]of integer;
        var x :array[1 .. 3] of integer;
        begin
            return x;
        end
        procedure main ();
        var a:array[1 .. 5] of integer;
            d:integer;
            e:real;
        begin
            e:=d(2);
        end
        var g:real;
        """ 
        expect = "Undeclared Function: d"
        self.assertTrue(TestChecker.test(input,expect,468))
    def test_69(self):
        """More complex program"""
        input = """
        function f1():array[1 .. 3]of integer;
        var x :array[1 .. 3] of integer;
        begin
            return x;
        end
        procedure main ();
        var a:array[1 .. 5] of integer;
            d:integer;
            e:real;
        begin
            d(2)[3]:=5;
        end
        var g:real;
        """ 
        expect = "Undeclared Function: d"
        self.assertTrue(TestChecker.test(input,expect,469))
    def test_70(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin
            if(x>y)then
                return 1;
            else return 2;
        end
        procedure main ();
        var x:real;
        begin
            f := f();
        end
        """ 
        expect = "Undeclared Identifier: f"
        self.assertTrue(TestChecker.test(input,expect,470))
    def test_71(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin
            if(x>y)then
                return 1;
            return 2;
        end
        procedure main ();
        var x:real;
        begin
            f := f();
        end
        """ 
        expect = "Undeclared Identifier: f"
        self.assertTrue(TestChecker.test(input,expect,471))
    def test_72(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin
            if(x>y)then
                return 1;
        end
        procedure main ();
        var x:real;
        begin
            x:=f();
        end
        """ 
        expect = "Function f Not Return "
        self.assertTrue(TestChecker.test(input,expect,472))
    def test_73(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin
            if(x>y)then
                x:=y;
            else
                return 1;
        end
        procedure main ();
        var x:real;
        begin
            x:=f();
        end
        """ 
        expect = "Function f Not Return "
        self.assertTrue(TestChecker.test(input,expect,473))
    def test_74(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin
            x:=y;
            y:=x+1;
            y:=x*x;
            if(x>y)then
                return x;
            else
                return y;
        end
        procedure main ();
        var x:real;
        begin
            f:=f();
        end
        """ 
        expect = "Undeclared Identifier: f"
        self.assertTrue(TestChecker.test(input,expect,474))
    def test_75(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin
            with
                x:integer;
                y:boolean;
                z:real;
            do begin
                return y;
            end

        end
        procedure main ();
        var x:real;
        begin
            x:=f();
        end
        """ 
        expect = "Type Mismatch In Statement: Return(Some(Id(y)))"
        self.assertTrue(TestChecker.test(input,expect,475))
    def test_76(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin
            if(x>y)then
                return x;
            else
                return y;
        end
        procedure main ();
        var x:real;
        begin
            x:="abs";
        end
        """ 
        expect = "Type Mismatch In Statement: AssignStmt(Id(x),StringLiteral(abs))"
        self.assertTrue(TestChecker.test(input,expect,476))
    def test_77(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin
            with
                x:integer;
                y:boolean;
                z:real;
            do begin
                if (x>10) then return 10;
            end

        end
        procedure main ();
        var x:real;
        begin
            x:=f();
        end
        """ 
        expect = "Function f Not Return "
        self.assertTrue(TestChecker.test(input,expect,477))
    def test_78(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin
            with
                x:integer;
                y:boolean;
                z:real;
            do begin
                if (x>10) then return 10;
                else return 100;
            end
        end
        procedure main ();
        var x:real;
        begin
            f:=f();
        end
        """ 
        expect = "Undeclared Identifier: f"
        self.assertTrue(TestChecker.test(input,expect,478))
    def test_79(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin
            with
                x:integer;
                y:boolean;
                z:real;
            do begin
                if (x>10) then return 10;
            end
        end
        procedure main ();
        var x:real;
        begin
            x:=f();
        end
        """ 
        expect = "Function f Not Return "
        self.assertTrue(TestChecker.test(input,expect,479))
    def test_80(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin
            with
                x:integer;
                y:boolean;
                z:real;
            do begin
                if (x>10) then return 10;
            end
            return 10;

        end
        procedure main ();
        var x:real;
        begin
            x1:=f();
        end
        """ 
        expect = "Undeclared Identifier: x1"
        self.assertTrue(TestChecker.test(input,expect,480))
    def test_81(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin
            for x:=5 to 100 do
            begin
                return 10;
            end
        end
        procedure main ();
        var x:real;
        begin
            x:=f();
        end
        """ 
        expect = "Function f Not Return "
        self.assertTrue(TestChecker.test(input,expect,481))
    def test_82(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin

            while(x<y) do
            begin
                return 10;
            end
        end
        procedure main ();
        var x:real;
        begin
            x:=f();
        end
        """ 
        expect = "Function f Not Return "
        self.assertTrue(TestChecker.test(input,expect,482))
    def test_83(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin

            while(x<y) do
            begin
                if(x=5) then return 1;
                else return 10;
            end
        end
        procedure main ();
        var x:real;
        begin
            x:=f();
        end
        """ 
        expect = "Function f Not Return "
        self.assertTrue(TestChecker.test(input,expect,483))
    def test_84(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin

            while(x<y) do
            begin
                with x:integer;y:real; do
                begin
                    return x*x;
                end
            end
        end
        procedure main ();
        var x:real;
        begin
            x:=f();
        end
        """ 
        expect = "Function f Not Return "
        self.assertTrue(TestChecker.test(input,expect,484))
    def test_85(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin

            while(x<y) do
            begin
                if (x=5)then 
                begin
                    k:=6;
                    break;
                end
                else 
                begin
                    x:=5;
                    break;
                end
            end
            return x;
        end
        procedure main ();
        var x:real;
        begin
            x:=f();
        end
        """ 
        expect = "Undeclared Identifier: k"
        self.assertTrue(TestChecker.test(input,expect,485))
    def test_86(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin
            foo1();
        end
        procedure main ();
        var x:real;
        begin
            x:=f();
        end
        """ 
        expect = "Undeclared Procedure: foo1"
        self.assertTrue(TestChecker.test(input,expect,486))
    def test_87(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin
            x:=foo1();
        end
        procedure main ();
        var x:real;
        begin
        end
        """ 
        expect = "Undeclared Function: foo1"
        self.assertTrue(TestChecker.test(input,expect,487))
    def test_88(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin
            x:=foo1(t+1);
        end
        procedure main ();
        var x:real;
        begin
        end
        """ 
        expect = "Undeclared Identifier: t"
        self.assertTrue(TestChecker.test(input,expect,488))
    def test_89(self):
        """More complex program"""
        input = """
        function f():integer;
        var x,y:integer;
        begin
            x:=foo1(b[foo2()]);
        end
        procedure main ();
        var x:real;
        begin
        end
        """ 
        expect = "Undeclared Function: foo2"
        self.assertTrue(TestChecker.test(input,expect,489))
    def test_90(self):
        """More complex program"""
        input = """
        var putIntLn:integer;

        function f():integer;
        var x,y:integer;
        begin
            x:=foo1(b[foo2()]);
        end
        procedure main ();
        var x:real;
        begin
        end
        """ 
        expect = "Redeclared Variable: putIntLn"
        self.assertTrue(TestChecker.test(input,expect,490))
    def test_91(self):
        """More complex program"""
        input = """
        var putFloatLn:integer;
        
        function f():integer;
        var x,y:integer;
        begin
            x:=foo1(b[foo2()]);
        end
        procedure main ();
        var x:real;
        begin
        end
        """ 
        expect = "Redeclared Variable: putFloatLn"
        self.assertTrue(TestChecker.test(input,expect,491))
    def test_92(self):
        """More complex program"""
        input = """
        procedure main ();
        var x,y:real;
        begin
            x:= getFloat();
            y:= getInt(x);
        end
        """ 
        expect = "Type Mismatch In Expression: CallExpr(Id(getInt),[Id(x)])"
        self.assertTrue(TestChecker.test(input,expect,492))
    def test_93(self):
        """More complex program"""
        input = """
        procedure main ();
        var x,y:real;
        begin
            x:= putFloatLn();
            y:= getInt(x);
        end
        """ 
        expect = "Undeclared Function: putFloatLn"
        self.assertTrue(TestChecker.test(input,expect,493))
    def test_94(self):
        """More complex program"""
        input = """
        procedure f();
        begin 
        end
        procedure main ();
        var x,y:real;
        begin
            x:= f();
        end
        """ 
        expect = "Undeclared Function: f"
        self.assertTrue(TestChecker.test(input,expect,494))
    def test_95(self):
        """More complex program"""
        input = """
        function f():integer;
        begin
            return 2; 
        end
        procedure main ();
        var x,y:real;
        begin
            f();
        end
        """ 
        expect = "Undeclared Procedure: f"
        self.assertTrue(TestChecker.test(input,expect,495))
    def test_96(self):
        """More complex program"""
        input = """
        function f():integer;
        begin
            return 2; 
        end
        procedure main ();
        var x,y:real;
        begin
            with x,y:integer;
            do begin
            for x:= y to 100 do
            begin
                
                x := getInt();
                y := putInt(x);
                if(x>10.5)then
                begin
                    break;     
                end
                else x:=x*50;

            end
            end
        end
        """ 
        expect = "Undeclared Function: putInt"
        self.assertTrue(TestChecker.test(input,expect,496))
    def test_97(self):
        """More complex program"""
        input = """
        function f():integer;
        begin
            return 2; 
        end
        procedure main ();
        var x,y:real;
        begin
            with x,y:integer;
            do begin
            for x:= y to 100 do
            begin
                
                x := getInt();
                putInt(x);
                if(x>10.5)then
                begin
                    break;     
                end
                else x:=x*50.5;

            end
            end
        end
        """ 
        expect = "Type Mismatch In Statement: AssignStmt(Id(x),BinaryOp(*,Id(x),FloatLiteral(50.5)))"
        self.assertTrue(TestChecker.test(input,expect,497))
    def test_98(self):
        """More complex program"""
        input = """
        function giaithua(n:integer):integer;
        begin
            if n = 0 then return 1;
            else return n*giaithua(n-1);
        end
        procedure main ();
        var x,y:real;
            n:integer;
        begin
            putStringLn("Nhap vao so n");
            n:=getInt();
            putIntLn(giaithua(n));
            n := y := giaithua(n);
            break;
        end
        """ 
        expect = "Type Mismatch In Statement: AssignStmt(Id(n),Id(y))"
        self.assertTrue(TestChecker.test(input,expect,498))
    def test_99(self):
        """More complex program"""
        input = """
        function sumarray(arr:array[1 .. 10]of integer):integer;
        var i,x,s:integer;
        begin
            s:=0;
            for i:= 1 to 10 do
            begin
                s:=s+arr[i];       
            end
            return s;
        end
        procedure main ();
        var x,y:real;
            i:integer;
            arr:array[1 .. 10]of integer;
        begin
            for i:=1 to 10 do
            begin
                putIntLn(arr[i]);
            end
            putIntLn(sumarray(arr));
            return arr[5];
        end
        """ 
        expect = "Type Mismatch In Statement: Return(Some(ArrayCell(Id(arr),IntLiteral(5))))"
        self.assertTrue(TestChecker.test(input,expect,499))