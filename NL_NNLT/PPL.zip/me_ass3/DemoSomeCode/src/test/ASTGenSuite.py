import unittest
from TestUtils import TestAST
from AST import *

class ASTGenSuite(unittest.TestCase):
    def test_simple_function_1(self):
        input = """
        function main(x,y:integer):array[1 .. 5]of integer;
        var a:real;
        begin
            putInt(x+5,x*x);
            putInt(-x);
        end"""
        expect = ""
        expect = str(Program([
            FuncDecl(
                Id("main"),
                [VarDecl(Id("x"),IntType()),VarDecl(Id("y"),IntType())]
                
                ,[VarDecl(Id("a"),FloatType())]
                ,
                [
                CallStmt(Id("putInt"),[BinaryOp("+",Id("x"),IntLiteral(5)),BinaryOp("*",Id("x"),Id("x"))]),
                CallStmt(Id("putInt"),[UnaryOp("-",Id("x"))])
                ],ArrayType(1,5,IntType()))]))
        if type(ArrayType(1,5,IntType())) == ArrayType:
            print("FUckckckckcks")
        print(type(ArrayType(1,5,IntType())))
        self.assertTrue(TestAST.test(input,expect,300))
   