import unittest
from TestUtils import TestChecker
from AST import *

class CheckerSuite(unittest.TestCase):
    def test_98(self):
        """More complex program"""
        input = """
        function giaithua(n:integer):integer;
        begin
            if n = 0 then return 1;
            else return n*giaithua(n-1);
        end
        procedure main ();
        var x,y:real;
        begin
            putStringLn("Nhap vao so n");
        end
        """ 
        expect = "Type Mismatch In Statement: AssignStmt(Id(x),BinaryOp(*,Id(x),FloatLiteral(50.5)))"
        self.assertTrue(TestChecker.test(input,expect,498))
    def test_99(self):
        """More complex program"""
        input = """
        function sumarray(arr:array[1 .. 10]of integer):integer;
        var i,x,s:integer;
        begin
            s:=0;
            for i:= 1 to 10 do
            begin
                s:=s+arr[i];       
            end
            return s;
        end
        procedure main ();
        var x,y:real;
            arr:array[1 .. 20]of integer;
            arr2:array[1 .. 20]of integer;
        begin
            arr:=arr2;
            //x:=sumarray(arr);
        end
        """ 
        expect = "Type Mismatch In Statement: AssignStmt(Id(x),BinaryOp(*,Id(x),FloatLiteral(50.5)))"
        self.assertTrue(TestChecker.test(input,expect,499))