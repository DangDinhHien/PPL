
"""
 * @author nhphung
"""
from AST import * 
from Visitor import *
from Utils import Utils
from StaticError import *

class MType:
    def __init__(self,partype,rettype):
        self.partype = partype
        self.rettype = rettype

class Symbol:
    def __init__(self,name,mtype,value = None):
        self.name = name
        self.mtype = mtype
        self.value = value

class StaticChecker(BaseVisitor,Utils):

    global_envi = [Symbol("io",ClassType(Id("io")))]
            
    
    def __init__(self,ast):
        self.ast = ast
   
    def check(self):
        return self.visit(self.ast,StaticChecker.global_envi)
    
    def checkRedeclare(self,name,lst,kind):
    	if self.lookup(name,lst,lambda x:x):
    		raise Redeclared(kind,name)
    	return lst + [name]
    
    def visitProgram(self,ast, c): 
    	rawclass = [x.classname.name for x in ast.decl]
    	lstclass = reduce(lambda x,y: self.checkRedeclared(x,y,Class()),rawclass,"io")
    	return lstclass
        

    

